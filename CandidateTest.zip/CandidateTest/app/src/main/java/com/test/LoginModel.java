package com.test;

public class LoginModel {
    private String email,secret;

    public LoginModel(String email, String secret) {
        this.email = email;
        this.secret = secret;
    }
}
